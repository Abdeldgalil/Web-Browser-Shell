import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.workspace.webbrowsershell',
  appName: 'Web Browser Shell',
  webDir: 'dist',
  // The host app WebView background must be transparent wherever the
  // embedded page (opened via InAppBrowser) should show through.
  backgroundColor: '#00000000',
  android: {
    allowMixedContent: true,
  },
};

export default config;
